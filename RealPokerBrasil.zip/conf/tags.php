<?php
	#Defini��es do Sistema
	date_default_timezone_set('America/Sao_Paulo');
	define('UrlPadrao' , "http://".$_SERVER['HTTP_HOST']."/RealPokerBrasil/");
	
	#Defini��es do Banco de Dados
	define('DB_Host' , "db4free.net");
	define('DB_Database' , "realpokerbrasil");
	define('DB_User' , "realpokerbrasil");
	define('DB_Pass' , "s1stem@");
?>