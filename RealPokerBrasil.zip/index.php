<?php
	ini_set('display_errors', '1');
	@require('conf/controle.php');
	#Inicia Controle
	$controle = new controle();
?>